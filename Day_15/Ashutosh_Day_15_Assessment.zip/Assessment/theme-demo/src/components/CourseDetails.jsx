export default function CourseDetails() {
  return (
    <div className="alert alert-primary mt-3">
      <h4>Course Details Loaded!</h4>
      <p>This module was loaded lazily using React.lazy().</p>
    </div>
  );
}
