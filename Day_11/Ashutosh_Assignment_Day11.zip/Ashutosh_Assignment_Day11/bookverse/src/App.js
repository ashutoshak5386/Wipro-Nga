import React from "react";
import BookList from "./components/BookList";

function App() {
  return <BookList />;
}

export default App;
