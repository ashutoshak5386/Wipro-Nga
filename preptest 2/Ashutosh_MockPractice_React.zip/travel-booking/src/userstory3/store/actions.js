// src/userstory3/store/actions.js
export const setStatus = (status) => ({ type: 'SET_STATUS', payload: status });
