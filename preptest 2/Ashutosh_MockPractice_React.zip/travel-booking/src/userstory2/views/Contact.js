// src/userstory2/views/Contact.js
export default function Contact() {
  return (
    <div className="container my-4">
      <h4>Contact Us</h4>
      <p>Email: support@example.com</p>
    </div>
  );
}
