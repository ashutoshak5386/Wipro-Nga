export default function InstructorProfile() {
  return (
    <div className="alert alert-success mt-3">
      <h4>Instructor Profile Loaded!</h4>
      <p>This component also uses code splitting.</p>
    </div>
  );
}
